package display.connection;

import java.sql.Connection;

public interface DBConnection {
    Connection getConnection();
}
