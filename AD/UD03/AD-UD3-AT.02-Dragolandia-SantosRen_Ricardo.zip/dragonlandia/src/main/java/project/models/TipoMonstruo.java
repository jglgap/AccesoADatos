package project.models;

public enum TipoMonstruo {

    OGRO,TROLL,ESPECTRO
}
